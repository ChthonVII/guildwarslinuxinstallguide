************************************************
*	Guild Wars DirectSong Playlist Editor  *
*	Version 1.03                           *
*	Silent Coyote                          *
*	http://silentcoyote.co.uk/             *
************************************************

Index:
******

1. Update Notes

2. Requirements

3. Installation

4. Upgrading From Previous Versions

5. Usage

6. Troubleshooting

7. Misc Stuff

1. Update Notes
***************

v1.03:
	* Application better handles incorrectly formatted DS files.
	* Application will now display a warning if it detects an incorrectly formatted line in the ds file.
	* Improved an error message.

v1.02:
	* Application no longer removes comments from DS file.
	* Added support for level specific tokens.
	* Added edit area data window.
	* Modified the way application settings are handled.
	* No longer adds default playlist (*) to empty tokens.
	* Application now saves last used search settings.
	* Fixed right mouse button click bug with area list.
	* Playlist title now includes campaign name.
	* Changed tab order of components.
	* Added location data for most levels.
	* Added location data for battle tokens.

v1.01:
	* Fixed bug which removed known tokens from the DS file.
	* Made minor improvements to the search feature.
	* Added location data for Shing Jea Island tokens.

v1.00:
	* First release.

2. Requirements
***************

	* .NET Framework 2.0.
	* An Installed DirectSong pack (see www.directsong.com).
	* Guild Wars.

3. Installation
***************

** Important: Guild Wars DirectSong Playlist Editor requires .NET FrameWork 2.0. **

** Important: You must have a DirectSong music pack installed before using the playlist 
editor. Visit www.directsong.com to download the free Sorrows Furnace DirectSong pack. **

To install simply extract the application to your desired location. It is required that all components of the
application be installed to the same directory (though this may be a different location to that of your DS file).
Please take a moment to ensure that your install directory contains all of the following files:
	* GW DirectSong Playlist Editor.exe
	* DirectSongParser.dll
	* dsData.xml

If one of the above files is missing please try installing the application again. After the application has been
started for the first time it will create a settings file (settings.ini) in the same directory as it was installed
to.

4. Upgrading From Previous Versions
***********************************

** If you have been using a version of the playlist editor prior to v1.02 it is recommended that you restore the
default DS file. When you first executed the playlist editor it should have created a file named GuildWars.ds_backup
in the same location as your DS file. Simply delete the DS file and remove _backup from the backup copy. **

** Setting files from older versions are no longer compatible with v1.02. Please delete any older settings files and 
allow the application to create a new one on startup. **

If installing over an older version of the application just replace the old exe, dll, ini, and xml file with the new
versions.

5. Usage
********

The Guild Wars DirectSong Playlist Editor is a tool for modifying the DS file used by Guild Wars and DirectSong to
determine which music tracks play in each area of the game. Custom playlist can be created for each level of the
game which will trigger when that level loads.

To use execute 'GW DirectSong Playlist Editor.exe', it will prompt you to enter the location of your DS file. Once the 
DS file has been located the application will start. To modify the playlist for an area locate the area in the tree
view on the left or using the search feature. On selecting a level its current playlist will appear on the right. From
here you can add, delete, or modify songs in the playlist. Once all required changes have been made click the OK button to
save your changes and exit the application. The modified playlist should be used next time you start Guild Wars.

6. Troubleshooting
******************

Problem - Upon executing I recive the following error message: The application failed to initialize properly (0xc0000135).
Solution - This is caused by not having the .NET Framework installed. Download the .NET Framework 2.0 from the Microsoft Download Center.

7. Misc Stuff
*************

Thanks to:
	* Ekelon for the guide on DS tokens (http://www.guildwarsguru.com/forum/showthread.php?t=10269138).
	* R.O.B for information on the level specific tokens.
	* EternalTempest for compiling a great DirectSong FAQ (http://www.guildwarsguru.com/forum/showthread.php?t=10069916).

Please send any bug reports to SilentCoyote@SilentCoyote.co.uk.
